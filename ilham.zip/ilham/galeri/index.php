<?php
header('location:../');
?>