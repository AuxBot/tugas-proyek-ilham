<?php
//sidenav

$jancok = "
<P>jamcon aAAAAAAAAAAAAAAAAAAAAAAAAAAAA</p>
"

?>